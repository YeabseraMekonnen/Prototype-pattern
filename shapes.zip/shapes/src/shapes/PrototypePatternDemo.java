package shapes;

public class PrototypePatternDemo {

    public static void main(String[] args) {
        ShapeCache.loadCache();

        Shapes clonedShape = (Shapes) ShapeCache.getShape("1");
        System.out.println("Shape : " + clonedShape.getType());

        Shapes clonedShape2 = (Shapes) ShapeCache.getShape("2");
        System.out.println("Shape : " + clonedShape2.getType());

        Shapes clonedShape3 = (Shapes) ShapeCache.getShape("3");
        System.out.println("Shape : " + clonedShape3.getType());
    }
}
