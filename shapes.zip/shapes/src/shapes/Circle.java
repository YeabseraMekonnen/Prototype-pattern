
package shapes;


public class Circle extends Shapes{
     public Circle(){
     type = "Circle";
   }

   @Override
   public void draw() {
      System.out.println("Inside Circle::draw() method.");
   }
    
}
